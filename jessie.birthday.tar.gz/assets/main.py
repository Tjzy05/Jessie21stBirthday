import pygame
import sys
import math
from collections import deque
import asyncio

# --- Settings ---
TILE = 50
COLS = 10
ROWS = 10
RIGHT_SIDEBAR = 100
LEFT_SIDEBAR = 250
WIDTH = LEFT_SIDEBAR + COLS * TILE + RIGHT_SIDEBAR
HEIGHT = ROWS * TILE
FPS = 60

# --- Colors ---
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (30, 30, 180)
YELLOW = (255, 220, 0)
BEAVER = (159, 129, 112)
BISTRE = (61, 43, 31)
LIGHTBROWN = (107, 53, 17)

LINE_WIDTH = 4

# Language Setting
LANG = "en"

TEXTS = {
    "en": {
        "mission_title": "CURRENT MISSION",
        "collected_title": "COLLECTED",
        "bring": "Bring the {item}",
        "all_done": "All ingredients collected!",
        "happy_birthday": "Happy Birthday Jessie!",
        "info_title": "How to Play",
        "info_lines": [
            "Use arrow keys / WASD to move",
            "Jessie The Mouse.",
            "Collect all 6 cake ingredients.",
            "Rmb to avoid Tina and ",
            "Lotus The Cats!!",
            "You have 3 lives."
        ],
        "lang_button": "CHN",
        "game_over": "Game Over."
    },
    "zh": {
        "mission_title": "當前任務",
        "collected_title": "已收集",
        "bring": " 收集{item}。",
        "all_done": "所有材料都收集完成！",
        "happy_birthday": "雀屎生日快樂!",
        "info_title": "游戲説明",
        "info_lines": [
            "用方向盤或WASD移動Jessie The Mouse",
            " 收集共6種蛋糕材料。",
            "記得躲避Tina和Lotus The Cats!!",
            " 你一共有三條命。"
        ],
        "lang_button": "ENG",
        "game_over": "游戲結束"
    }
}

def t(key):
    return TEXTS[LANG][key]

H_WALLS = [[False] * COLS for _ in range(ROWS + 1)]
V_WALLS = [[False] * (COLS + 1) for _ in range(ROWS)]

def add_border_walls():
    for c in range(COLS):
        H_WALLS[0][c] = True
        H_WALLS[ROWS][c] = True
    for r in range(ROWS):
        V_WALLS[r][0] = True
        V_WALLS[r][COLS] = True

def add_wall_between(c1, r1, c2, r2):
    if r1 == r2:
        col = min(c1, c2) + 1
        V_WALLS[r1][col] = True
    elif c1 == c2:
        row = min(r1, r2) + 1
        H_WALLS[row][c1] = True

add_border_walls()
add_wall_between(1,0,2,0); add_wall_between(4,1,5,1); add_wall_between(6,1,7,1); add_wall_between(1,2,2,2)
add_wall_between(2,2,3,2); add_wall_between(2,3,3,3); add_wall_between(7,3,8,3); add_wall_between(0,4,1,4)
add_wall_between(1,4,2,4); add_wall_between(4,4,5,4); add_wall_between(8,4,9,4); add_wall_between(0,5,1,5)
add_wall_between(3,5,4,5); add_wall_between(5,5,6,5); add_wall_between(1,6,2,6); add_wall_between(6,6,7,6)
add_wall_between(2,7,3,7); add_wall_between(4,7,5,7); add_wall_between(7,7,8,7); add_wall_between(0,8,1,8)
add_wall_between(3,8,4,8); add_wall_between(5,8,6,8); add_wall_between(1,9,2,9); add_wall_between(4,9,5,9)
add_wall_between(5,9,6,9); add_wall_between(7,9,8,9); add_wall_between(2,0,2,1); add_wall_between(4,0,4,1)
add_wall_between(1,2,1,3); add_wall_between(3,2,3,3); add_wall_between(5,2,5,3); add_wall_between(6,1,6,2)
add_wall_between(7,1,7,2); add_wall_between(5,3,5,4); add_wall_between(7,3,7,4); add_wall_between(9,3,9,4)
add_wall_between(0,4,0,5); add_wall_between(2,4,2,5); add_wall_between(6,4,6,5); add_wall_between(2,5,2,6)
add_wall_between(3,5,3,6); add_wall_between(9,5,9,6); add_wall_between(4,6,4,7); add_wall_between(5,6,5,7)
add_wall_between(7,6,7,7); add_wall_between(8,6,8,7); add_wall_between(0,7,0,8); add_wall_between(1,7,1,8)
add_wall_between(2,8,2,9); add_wall_between(3,8,3,9); add_wall_between(6,8,6,9)

def can_move_between(r1, c1, r2, c2):
    if r1 == r2:
        col = min(c1, c2) + 1
        return not V_WALLS[r1][col]
    if c1 == c2:
        row = min(r1, r2) + 1
        return not H_WALLS[row][c1]
    return False

def draw_maze(surface):
    for r in range(ROWS + 1):
        for c in range(COLS):
            if H_WALLS[r][c]:
                x, y = LEFT_SIDEBAR + c * TILE, r * TILE
                pygame.draw.line(surface, WHITE, (x, y), (x + TILE, y), LINE_WIDTH)
    for r in range(ROWS):
        for c in range(COLS + 1):
            if V_WALLS[r][c]:
                x, y = LEFT_SIDEBAR + c * TILE, r * TILE
                pygame.draw.line(surface, WHITE, (x, y), (x, y + TILE), LINE_WIDTH)

def draw_dashed_line(surface, color, start_pos, end_pos, width=2, dash_length=8):
    x1, y1 = start_pos
    x2, y2 = end_pos
    if x1 == x2:
        step = dash_length if y2 >= y1 else -dash_length
        y = y1
        while (step > 0 and y < y2) or (step < 0 and y > y2):
            y_end = y + step // 2
            pygame.draw.line(surface, color, (x1, y), (x1, y_end), width)
            y += step
    else:
        step = dash_length if x2 >= x1 else -dash_length
        x = x1
        while (step > 0 and x < x2) or (step < 0 and x > x2):
            x_end = x + step // 2
            pygame.draw.line(surface, color, (x, y1), (x_end, y1), width)
            x += step

def draw_dashed_rect(surface, rect, color, width=2, dash_length=8):
    x, y, w, h = rect
    draw_dashed_line(surface, color, (x, y), (x + w, y), width, dash_length)
    draw_dashed_line(surface, color, (x, y + h), (x + w, y + h), width, dash_length)
    draw_dashed_line(surface, color, (x, y), (x, y + h), width, dash_length)
    draw_dashed_line(surface, color, (x + w, y), (x + w, y + h), width, dash_length)

def get_neighbors(row, col):
    neighbors = []
    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nr, nc = row + dr, col + dc
        if 0 <= nr < ROWS and 0 <= nc < COLS and can_move_between(row, col, nr, nc):
            neighbors.append((nr, nc))
    return neighbors

def bfs(start, goal):
    if start == goal: return [start]
    visited = {start}
    queue = deque([[start]])
    while queue:
        path = queue.popleft()
        r, c = path[-1]
        for nr, nc in get_neighbors(r, c):
            if (nr, nc) not in visited:
                new_path = path + [(nr, nc)]
                if (nr, nc) == goal: return new_path
                visited.add((nr, nc))
                queue.append(new_path)
    return []

def dfs(start, goal):
    if start == goal: return [start]
    visited = {start}
    stack = [[start]]
    while stack:
        path = stack.pop()
        r, c = path[-1]
        if (r, c) == goal: return path
        for nr, nc in get_neighbors(r, c):
            if (nr, nc) not in visited:
                visited.add((nr, nc))
                stack.append(path + [(nr, nc)])
    return []

class Player:
    def __init__(self, row, col, image=None):
        self.row = row
        self.col = col
        self.x = LEFT_SIDEBAR + col * TILE
        self.y = row * TILE
        self.speed = 2
        self.dir = (0, 0)
        self.next_dir = (0, 0)
        self.image = image
        self.scale_timer = 0
        self.scale_speed = 0.1
        self.scale_amount = 0.05

    def set_direction(self, dx, dy): self.next_dir = (dx, dy)
    def if_centered(self): return self.x % TILE == 0 and self.y % TILE == 0
    def can_move(self, dx, dy):
        target_col, target_row = self.col + dx, self.row + dy
        if target_row < 0 or target_row >= ROWS or target_col < 0 or target_col >= COLS:
            return False
        return can_move_between(self.row, self.col, target_row, target_col)

    def update(self):
        if self.if_centered():
            self.col = (self.x - LEFT_SIDEBAR) // TILE
            self.row = self.y // TILE
            if self.next_dir != (0, 0) and self.can_move(*self.next_dir):
                self.dir = self.next_dir
            elif not self.can_move(*self.dir):
                self.dir = (0, 0)
        self.x += self.dir[0] * self.speed
        self.y += self.dir[1] * self.speed
        self.scale_timer += self.scale_speed

    def reset_position(self, row, col):
        self.row, self.col = row, col
        self.x, self.y = LEFT_SIDEBAR + col * TILE, row * TILE
        self.dir, self.next_dir = (0, 0), (0, 0)

    def draw(self, surface):
        scale_factor = 1 + math.sin(self.scale_timer) * self.scale_amount
        if self.image:
            base_w, base_h = self.image.get_width(), self.image.get_height()
            scaled_img = pygame.transform.scale(self.image, (int(base_w * scale_factor), int(base_h * scale_factor)))
            img_rect = scaled_img.get_rect(center=(self.x + TILE // 2, self.y + TILE // 2))
            surface.blit(scaled_img, img_rect)

class Ghost:
    def __init__(self, row, col, image=None, algorithm="bfs", recalc_interval=20):
        self.home_row, self.home_col = row, col
        self.row, self.col = row, col
        self.x, self.y = LEFT_SIDEBAR + col * TILE, row * TILE
        self.speed = 2
        self.dir = (0, 0)
        self.image = image
        self.algorithm = algorithm
        self.path = []
        self.recalc_timer = 0
        self.recalc_interval = recalc_interval

    def if_centered(self): return self.x % TILE == 0 and self.y % TILE == 0
    def update(self, target_row, target_col):
        if self.if_centered():
            self.col = (self.x - LEFT_SIDEBAR) // TILE
            self.row = self.y // TILE
            self.recalc_timer -= 1
            if self.recalc_timer <= 0 or not self.path:
                self.path = bfs((self.row, self.col), (target_row, target_col)) if self.algorithm == "bfs" else dfs((self.row, self.col), (target_row, target_col))
                self.recalc_timer = self.recalc_interval
            if len(self.path) > 1:
                next_row, next_col = self.path[1]
                self.dir = (next_col - self.col, next_row - self.row)
                self.path.pop(0)
            else:
                self.dir = (0, 0)
        self.x += self.dir[0] * self.speed
        self.y += self.dir[1] * self.speed

    def respawn(self):
        self.row, self.col = self.home_row, self.home_col
        self.x, self.y = LEFT_SIDEBAR + self.home_col * TILE, self.home_row * TILE
        self.dir, self.path = (0, 0), []

    def draw(self, surface):
        if self.image:
            img_rect = self.image.get_rect(center=(self.x + TILE // 2, self.y + TILE // 2))
            surface.blit(self.image, img_rect)

class Button:
    def __init__(self, x, y, width, height, image):
        self.rect = pygame.Rect(x, y, width, height)
        self.image = pygame.transform.scale(image, (width, height))
    def draw(self, surface): surface.blit(self.image, self.rect)
    def is_clicked(self, pos): return self.rect.collidepoint(pos)

class TextButton:
    def __init__(self, x, y, width, height): self.rect = pygame.Rect(x, y, width, height)
    def draw(self, surface):
        pygame.draw.rect(surface, (60, 60, 60), self.rect, border_radius=8)
        pygame.draw.rect(surface, WHITE, self.rect, width=2, border_radius=8)
        label = mission_font.render(t("lang_button"), True, WHITE)
        surface.blit(label, label.get_rect(center=self.rect.center))
    def is_clicked(self, pos): return self.rect.collidepoint(pos)

async def main():
    global LANG, lives, game_over, game_running, win_stage, win_timer, hit_flash_timer
    global mission_font, title_font

    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Cake Chase!")
    clock = pygame.time.Clock()

    # 關鍵修改：使用預設字型，避開 SysFont 在 Web 的崩潰問題
    mission_font = pygame.font.Font(None, 22)
    title_font = pygame.font.Font(None, 24)

    # 關鍵修改：移除了 .convert_alpha() 防止資源未載入完成就 crash
    jessie_img = pygame.transform.scale(pygame.image.load("heads/Jessie.png"), (TILE-10, TILE-10))
    tina_img = pygame.transform.scale(pygame.image.load("heads/Tina.png"), (TILE-10, TILE-10))
    lotus_img = pygame.transform.scale(pygame.image.load("heads/Lotus.png"), (TILE-10, TILE-10))

    play_img = pygame.image.load("buttons/Start.png")
    pause_img = pygame.image.load("buttons/Pause.png")
    restart_img = pygame.image.load("buttons/restart.png")
    info_img = pygame.image.load("buttons/info.png")
    ok_img = pygame.image.load("buttons/ok.png")

    white_heart_img = pygame.transform.scale(pygame.image.load("hearts/white_heart.png"), (50, 50))
    heart_img = pygame.transform.scale(pygame.image.load("hearts/heart.png"), (50, 50))

    egg_img = pygame.image.load("ingredients/egg.png")
    flour_img = pygame.image.load("ingredients/flour.png")
    milk_img = pygame.image.load("ingredients/milk.png")
    butter_img = pygame.image.load("ingredients/butter.png")
    strawberry_img = pygame.image.load("ingredients/strawberry.png")
    candle_img = pygame.image.load("ingredients/candles.png")
    cake_img = pygame.transform.scale(pygame.image.load("ingredients/birthdaycake.png"), (150, 150))

    player = Player(row=1, col=1, image=jessie_img)
    tina = Ghost(row=0, col=9, image=tina_img, algorithm="bfs", recalc_interval=20)
    lotus = Ghost(row=9, col=9, image=lotus_img, algorithm="dfs", recalc_interval=20)
    PLAYER_HOME = (1, 1)

    TINA_HOME_RECT = (LEFT_SIDEBAR + 9 * TILE, 0 * TILE, 1 * TILE, 1 * TILE)
    LOTUS_HOME_RECT = (LEFT_SIDEBAR + 9 * TILE, 9 * TILE, 1 * TILE, 1 * TILE)

    play_button = Button(WIDTH // 2 - 40, HEIGHT // 2 - 40, 120, 120, play_img)
    pause_button = Button(LEFT_SIDEBAR + COLS * TILE + 10, 10, 80, 80, pause_img)
    info_button = Button(LEFT_SIDEBAR + COLS * TILE + 30, 100, 40, 40, info_img)
    restart_button = Button(WIDTH // 2 - 40, HEIGHT // 2 - 40, 120, 120, restart_img)
    ok_button = Button(0, 0, 40, 40, ok_img)
    lang_button = TextButton(LEFT_SIDEBAR + COLS * TILE + 10, 150, 80, 40)

    missions = [
        {"name": "egg", "collected": False, "row": 2, "col": 3, "icon": egg_img},
        {"name": "flour", "collected": False, "row": 8, "col": 1, "icon": flour_img},
        {"name": "milk", "collected": False, "row": 1, "col": 6, "icon": milk_img},
        {"name": "butter", "collected": False, "row": 5, "col": 9, "icon": butter_img},
        {"name": "strawberry", "collected": False, "row": 9, "col": 4, "icon": strawberry_img},
        {"name": "candle", "collected": False, "row": 3, "col": 8, "icon": candle_img}
    ]

    INGREDIENT_NAMES = {
        "en": {"egg": "Egg", "flour": "Flour", "milk": "Milk", "butter": "Butter", "strawberry": "Strawberry", "candle": "Candle"},
        "zh": {"egg": "Egg", "flour": "Flour", "milk": "Milk", "butter": "Butter", "strawberry": "Strawberry", "candle": "Candle"}
    }

    def ingredient_name(key): return INGREDIENT_NAMES[LANG].get(key, key)
    def get_current_mission():
        for m in missions:
            if not m["collected"]: return t("bring").format(item=ingredient_name(m["name"]))
        return t("all_done")
    def get_current_icon(): return [m["icon"] for m in missions if m["collected"]]
    def get_current_ingredient():
        for m in missions:
            if not m["collected"]: return m
        return None
    def all_missions_done(): return all(m["collected"] for m in missions)
    def reset_missions():
        for m in missions: m["collected"] = False

    def draw_ingredients_on_map(surface):
        m = get_current_ingredient()
        if m is None: return
        x, y = LEFT_SIDEBAR + m["col"] * TILE, m["row"] * TILE
        icon = pygame.transform.scale(m["icon"], (TILE - 15, TILE - 15))
        surface.blit(icon, icon.get_rect(center=(x + TILE // 2, y + TILE // 2)))

    def draw_left_sidebar(surface, current_mission_text, collected_icons):
        for i in range(MAX_LIVES):
            x, y = 50 + i * 60, 60
            if hit_flash_timer > 0 and i == lives:
                img = white_heart_img if (hit_flash_timer // 6) % 2 == 0 else heart_img
                surface.blit(img, (x, y))
            elif i < lives: surface.blit(heart_img, (x, y))
            else: surface.blit(white_heart_img, (x, y))

        mission_y = 140
        surface.blit(title_font.render(t("mission_title"), True, WHITE), (10, mission_y))
        surface.blit(mission_font.render(current_mission_text, True, YELLOW), (10, mission_y + 30))

        collected_y = 250
        surface.blit(title_font.render(t("collected_title"), True, WHITE), (10, collected_y))
        icon_size = 30
        for i, icon_img in enumerate(collected_icons):
            row, col = i // 2, i % 2
            icon_x, icon_y = 10 + col * (icon_size + 10), collected_y + 30 + row * (icon_size + 10)
            surface.blit(pygame.transform.scale(icon_img, (icon_size, icon_size)), (icon_x, icon_y))

    def draw_info_popup(surface):
        pop_w, pop_h = 440, 260
        pop_rect = pygame.Rect(WIDTH // 2 - pop_w // 2, HEIGHT // 2 - pop_h // 2, pop_w, pop_h)
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        surface.blit(overlay, (0, 0))
        pygame.draw.rect(surface, (40, 40, 40), pop_rect, border_radius=12)
        pygame.draw.rect(surface, WHITE, pop_rect, width=2, border_radius=12)
        surface.blit(title_font.render(t("info_title"), True, YELLOW), (pop_rect.x + 20, pop_rect.y + 16))
        for i, line in enumerate(t("info_lines")):
            surface.blit(mission_font.render(line, True, WHITE), (pop_rect.x + 20, pop_rect.y + 60 + i * 28))
        ok_button.rect.topleft = (pop_rect.right - 90, pop_rect.bottom - 55)
        ok_button.draw(surface)

    def reset_game():
        global lives, game_over, game_running, win_stage, win_timer, hit_flash_timer
        lives, game_over, game_running = MAX_LIVES, False, False
        win_stage, win_timer, hit_flash_timer = None, 0, 0
        reset_missions()
        player.reset_position(*PLAYER_HOME)
        tina.respawn()
        lotus.respawn()

    def check_ghost_collision():
        return (player.row == tina.row and player.col == tina.col) or (player.row == lotus.row and player.col == lotus.col)

    game_running = False
    show_info = True
    game_over = False
    MAX_LIVES = 3
    lives = MAX_LIVES
    hit_flash_timer = 0
    HIT_FLASH_DURATION = 60
    win_stage = None
    win_timer = 0
    FLASH_DURATION, GATHER_DURATION, CAKE_DURATION = 90, 90, 120

    running = True
    while running:
        # 關鍵：每幀的第一行必須讓出時間給瀏覽器渲染繪製畫面！
        await asyncio.sleep(0)
        clock.tick(FPS)

        controls_active = game_running and not show_info and not game_over and win_stage is None and hit_flash_timer == 0

        for event in pygame.event.get():
            if event.type == pygame.QUIT: running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if lang_button.is_clicked(event.pos): LANG = "zh" if LANG == "en" else "en"
                elif show_info:
                    if ok_button.is_clicked(event.pos): show_info = False
                elif game_over:
                    if restart_button.is_clicked(event.pos): reset_game()
                elif not game_running and play_button.is_clicked(event.pos): game_running = True
                elif game_running and pause_button.is_clicked(event.pos): game_running = False
                elif info_button.is_clicked(event.pos): show_info = True; game_running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and not show_info and not game_over and win_stage is None:
                    game_running = not game_running
                elif game_running:
                    if event.key in (pygame.K_LEFT, pygame.K_a): player.set_direction(-1, 0)
                    elif event.key in (pygame.K_RIGHT, pygame.K_d): player.set_direction(1, 0)
                    elif event.key in (pygame.K_UP, pygame.K_w): player.set_direction(0, -1)
                    elif event.key in (pygame.K_DOWN, pygame.K_s): player.set_direction(0, 1)

        if controls_active:
            player.update()
            tina.update(player.row, player.col)
            lotus.update(player.row, player.col)
            ci = get_current_ingredient()
            if ci and player.row == ci["row"] and player.col == ci["col"]: ci["collected"] = True
            if check_ghost_collision():
                lives -= 1
                hit_flash_timer = HIT_FLASH_DURATION
                game_running = False
            if win_stage is None and all_missions_done():
                win_stage = "flash"
                win_timer = 0
                game_running = False

        if hit_flash_timer > 0:
            hit_flash_timer -= 1
            if hit_flash_timer == 0:
                player.reset_position(*PLAYER_HOME)
                tina.respawn()
                lotus.respawn()
                if lives <= 0: game_over = True
                else: game_running = True

        if win_stage is not None:
            win_timer += 1
            if win_stage == "flash" and win_timer >= FLASH_DURATION: win_stage, win_timer = "gather", 0
            elif win_stage == "gather" and win_timer >= GATHER_DURATION: win_stage, win_timer = "cake", 0
            elif win_stage == "cake" and win_timer >= CAKE_DURATION: win_stage, win_timer = "done", 0

        screen.fill(BLACK)
        if win_stage in (None, "flash"):
            draw_maze(screen)
            draw_ingredients_on_map(screen)
            show_chars = True if win_stage != "flash" else (win_timer // 8) % 2 == 0
            if show_chars:
                player.draw(screen)
                tina.draw(screen)
                lotus.draw(screen)
            draw_dashed_rect(screen, TINA_HOME_RECT, WHITE, width=4, dash_length=8)
            draw_dashed_rect(screen, LOTUS_HOME_RECT, WHITE, width=4, dash_length=8)
            draw_left_sidebar(screen, get_current_mission(), get_current_icon())
            lang_button.draw(screen)

            if game_over: restart_button.draw(screen)
            else:
                info_button.draw(screen)
                if game_running: pause_button.draw(screen)
                else: play_button.draw(screen)

        elif win_stage == "gather":
            t_progress = min(win_timer / GATHER_DURATION, 1)
            cx, cy, icon_size, collected_y = WIDTH // 2, HEIGHT // 2, 30, 250
            for i, m in enumerate(missions):
                sx = 10 + (i % 2) * (icon_size + 10) + icon_size // 2
                sy = collected_y + 30 + (i // 2) * (icon_size + 10) + icon_size // 2
                cur_x = sx + (cx - sx) * t_progress
                cur_y = sy + (cy - sy) * t_progress
                shrink = max(1 - t_progress, 0.05)
                base_zoom = icon_size / max(m["icon"].get_width(), 1)
                icon_spun = pygame.transform.rotozoom(m["icon"], win_timer * 6, base_zoom * shrink)
                screen.blit(icon_spun, icon_spun.get_rect(center=(cur_x, cur_y)))

        elif win_stage == "cake":
            t_progress = min(win_timer / CAKE_DURATION, 1)
            cake_spun = pygame.transform.rotozoom(cake_img, 360 * (1 - t_progress), 0.2 + 0.8 * t_progress)
            screen.blit(cake_spun, cake_spun.get_rect(center=(WIDTH // 2, HEIGHT // 2)))

        elif win_stage == "done":
            screen.blit(cake_img, cake_img.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
            text_surf = title_font.render(t("happy_birthday"), True, YELLOW)
            screen.blit(text_surf, text_surf.get_rect(center=(WIDTH // 2, HEIGHT // 2 + cake_img.get_height() // 2 + 30)))

        if show_info: draw_info_popup(screen)

        # 關鍵：將 flip() 放在主繪圖層的最外側，確保每幀一定刷新
        pygame.display.flip()

asyncio.run(main())